set PROJECT_NAME managed_ip_project
create_project ${PROJECT_NAME} ./${PROJECT_NAME} -part xc7a100tcsg324-1 -ip

set files [glob ./xci/*/*.{xci,xcix}]
add_files -norecurse $files
close_project
